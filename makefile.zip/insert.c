#include "funcoes.h"
#include "funcoesAuxiliares.h"

void insertIntoAux(char *nomeArquivo) {
    int id, idade; 
    char nomeJogador[30], nacionalidade[30], nomeClube[30], auxIdade[4];

    scanf("%d", &id);
    scan_quote_string(auxIdade);
    scan_quote_string(nomeJogador);
    scan_quote_string(nacionalidade);
    scan_quote_string(nomeClube);
    idade = atoi(auxIdade);
    if (idade == 0) {
        idade = -1;
    }

    FILE* nomearq = fopen(nomeArquivo, "rb+");
    if (nomearq == NULL) {
        printf("Falha no processamento do arquivo\n");
        exit(1);
    }

    CABECALHO cabecalho;
    ler_cabecalho(nomearq, &cabecalho);

    if (cabecalho.status == '0') {
        printf("Falha no processamento do arquivo\n");
        fclose(nomearq);
        exit(1);
    }

    reinserir_cabecalho(nomearq, &cabecalho, '0');

    REGISTRO* registro = criar_registro(id, idade, nomeJogador, nacionalidade, nomeClube);
    if (cabecalho.topo == -1) { // não tem registros removidos
        fseek(nomearq, 0, SEEK_END);
        inserirRegistro(registro, nomearq);
        cabecalho.prosByteOffset += registro->tamanhoRegistro;
        cabecalho.nroRegArq++;
        desalocarRegistro(&registro);
        reinserir_cabecalho(nomearq, &cabecalho, '1');
        fclose(nomearq);
        return;
    } 

    REGISTRO* anterior = (REGISTRO*) malloc(sizeof(REGISTRO));
    if (!anterior) {
        printf("Falha no processamento do arquivo.\n");
        exit(1);
    }
    fseek(nomearq, cabecalho.topo, SEEK_SET);
    ler_registro(anterior, nomearq);
    ler_lixo(nomearq);
    

    if (anterior->prox == -1) { // se só existe 1 registro removido
        if (registro->tamanhoRegistro <= anterior->tamanhoRegistro) {
            fseek(nomearq, (-1) * anterior->tamanhoRegistro, SEEK_CUR);
            int tamaux = registro->tamanhoRegistro;
            registro->tamanhoRegistro = anterior->tamanhoRegistro;
            inserirRegistro(registro, nomearq);
            preeche_vazio(nomearq, anterior->tamanhoRegistro - tamaux);
            cabecalho.topo = -1;
            cabecalho.nroRegRem--;
            cabecalho.nroRegArq++;
            reinserir_cabecalho(nomearq, &cabecalho, '1');
            desalocarRegistro(&anterior);
            desalocarRegistro(&registro);
            fclose(nomearq);
            return;
        } else { // insere no fim
            fseek(nomearq, 0, SEEK_END);
            inserirRegistro(registro, nomearq);
            cabecalho.prosByteOffset += registro->tamanhoRegistro;
            cabecalho.nroRegArq++;
            desalocarRegistro(&registro);
            reinserir_cabecalho(nomearq, &cabecalho, '1');
            fclose(nomearq);
            return;
        }
    } else if (registro->tamanhoRegistro <= anterior->tamanhoRegistro) { // se for o primeiro
        fseek(nomearq, (-1) * anterior->tamanhoRegistro, SEEK_CUR);
        int tamaux = registro->tamanhoRegistro;
        registro->tamanhoRegistro = anterior->tamanhoRegistro;
        inserirRegistro(registro, nomearq);
        preeche_vazio(nomearq, anterior->tamanhoRegistro - tamaux);
        cabecalho.topo = anterior->prox;
        cabecalho.nroRegRem--;
        cabecalho.nroRegArq++;
        reinserir_cabecalho(nomearq, &cabecalho, '1');
        desalocarRegistro(&anterior);
        desalocarRegistro(&registro);
        fclose(nomearq);
        return;
    }

    long int aux_anterior = cabecalho.topo; // anterior da onde eu quero inserir
    long int aux_atual = anterior->prox; // aonde eu quero inserir
    while (aux_atual != -1) { // pula o primeiro pq tratamos antes
        /* existe tres casos:
        1- só tem um removido (feita acima)
        2- inserção no início (feita acima)
        3- inserção no meio (feita abaixo)
        4- chegou ao fim */
         fseek(nomearq, aux_atual, SEEK_SET);
        REGISTRO* atual = (REGISTRO*) malloc(sizeof(REGISTRO));
        ler_registro(atual, nomearq);
        ler_lixo(nomearq);

        if (registro->tamanhoRegistro <= atual->tamanhoRegistro) {
                            
              anterior->prox = atual->prox;
            fseek(nomearq, (-1) * atual->tamanhoRegistro, SEEK_CUR);
            int tamaux = registro->tamanhoRegistro;
            registro->tamanhoRegistro = atual->tamanhoRegistro;
            inserirRegistro(registro, nomearq);
            preeche_vazio(nomearq, atual->tamanhoRegistro - tamaux);
            cabecalho.nroRegRem--;
            cabecalho.nroRegArq++;
            fseek(nomearq, aux_anterior, SEEK_SET);
            inserirRegistro(anterior, nomearq);
            
        
            
            reinserir_cabecalho(nomearq, &cabecalho, '1');
            desalocarRegistro(&atual);
            desalocarRegistro(&anterior);
            desalocarRegistro(&registro);
            fclose(nomearq);
            return; 
        }
                 
        anterior = atual;
        aux_anterior = aux_atual;
        aux_atual = atual->prox;
      
        
    } 

    fseek(nomearq, 0, SEEK_END);
    inserirRegistro(registro, nomearq);
    cabecalho.nroRegArq++;
    cabecalho.prosByteOffset += registro->tamanhoRegistro;
    reinserir_cabecalho(nomearq, &cabecalho, '1');
    desalocarRegistro(&registro);
    fclose(nomearq);
}

void insertInto(char *nomeArquivo, char *nomeIndice, int nroAdicoes) {
    for (int i = 0; i < nroAdicoes; i++) {
        insertIntoAux(nomeArquivo);
    }
    createIndex(nomeArquivo, nomeIndice);
}

// Função auxiliar responsável por desalocar a memória do registro
void desalocarRegistro(REGISTRO **registro) {
    // Libera a memória alocada para os campos de strings dentro da estrutura REGISTRO
    free((*registro)->nomeJogador);
    free((*registro)->nacionalidade);
    free((*registro)->nomeClube);
    // Libera a memória alocada para a estrutura REGISTRO
    free((*registro));
    // Define o ponteiro original como NULL
    *registro = NULL;
}
