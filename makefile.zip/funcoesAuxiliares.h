#ifndef FUNCOESAUXILARES_H
#define FUNCOESAUXILARES_H

#include "funcoes.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

#define TAM_CABECALHO 25

void reinserir_cabecalho(FILE *arquivo, CABECALHO *cabecalho, char status);
void ler_cabecalho(FILE *arquivo, CABECALHO *cabecalho);
void ler_registro(REGISTRO *registro, FILE *arquivo);
void preeche_vazio(FILE *arquivo, int tamanho);
void ler_lixo(FILE *file);
void updateList(FILE *arquivo, long int novo, int tamanhoRegistroNovo);
void updateCabecalho(FILE *arquivo, int nroRemocoes);
void recuperarRegistro(REGISTRO **registro, FILE *arquivo, int byteOffset, int *maxNomeJog, int *maxNacionalidade, int *maxNomeClube);
int testarArquivo(FILE *arquivo);
int comandoBusca(int *nroComandos, char (*comando)[5][20], char (*palavraChave)[5][100]);
int busca(REGISTRO *registro, REGISTRO_IND *vetorInd, int nroComandos, char comando[5][20], char palavraChave[5][100]);
long int buscaId(REGISTRO *registro, REGISTRO_IND *vetorInd, int nroRegistros, int nroComandos, char comando[5][20], char palavraChave[5][100]);
void impressaoRegistro(REGISTRO *registro);
REGISTRO_IND *recoverIndex(FILE *arquivo, FILE *indice);
REGISTRO *criar_registro(int id, int idade, const char *nomeJogador, const char *nacionalidade, const char *clube);
void inserirRegistro(REGISTRO *registro, FILE *arquivo); 
void alocarRegistro(REGISTRO **registro, int maxNomeJog, int maxNacionalidade, int maxNomeClube); 
void desalocarRegistro(REGISTRO **registro); 

#endif // FUNCOESAUXILARES_H
