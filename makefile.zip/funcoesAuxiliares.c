#include "funcoesAuxiliares.h"
#include "funcoes.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

void reinserir_cabecalho(FILE *arquivo, CABECALHO *cabecalho, char status) {
    cabecalho->status = status;
    fseek(arquivo, 0, SEEK_SET);
    fwrite(&cabecalho->status, sizeof(char), 1, arquivo);
    fwrite(&cabecalho->topo, sizeof(long int), 1, arquivo);
    fwrite(&cabecalho->prosByteOffset, sizeof(long int), 1, arquivo);
    fwrite(&cabecalho->nroRegArq, sizeof(int), 1, arquivo);
    fwrite(&cabecalho->nroRegRem, sizeof(int), 1, arquivo);
}

void ler_cabecalho(FILE *arquivo, CABECALHO *cabecalho) {
    fseek(arquivo, 0, SEEK_SET);
    fread(&cabecalho->status, sizeof(char), 1, arquivo);
    fread(&cabecalho->topo, sizeof(long int), 1, arquivo);
    fread(&cabecalho->prosByteOffset, sizeof(long int), 1, arquivo);
    fread(&cabecalho->nroRegArq, sizeof(int), 1, arquivo);
    fread(&cabecalho->nroRegRem, sizeof(int), 1, arquivo);
    
    
}

void ler_registro(REGISTRO *registro, FILE *arquivo) {
    fread(&registro->removido, sizeof(char), 1, arquivo);
    fread(&registro->tamanhoRegistro, sizeof(int), 1, arquivo);
    fread(&registro->prox, sizeof(long int), 1, arquivo);
    fread(&registro->id, sizeof(int), 1, arquivo);
    fread(&registro->idade, sizeof(int), 1, arquivo);
    fread(&registro->tamNomeJog, sizeof(int), 1, arquivo);
    registro->nomeJogador = (char *)malloc((registro->tamNomeJog + 1) * sizeof(char));
    fread(registro->nomeJogador, sizeof(char), registro->tamNomeJog, arquivo);
    registro->nomeJogador[registro->tamNomeJog] = '\0';
    fread(&registro->tamNacionalidade, sizeof(int), 1, arquivo);
    registro->nacionalidade = (char *)malloc((registro->tamNacionalidade + 1) * sizeof(char));
    fread(registro->nacionalidade, sizeof(char), registro->tamNacionalidade, arquivo);
    registro->nacionalidade[registro->tamNacionalidade] = '\0';
    fread(&registro->tamNomeClube, sizeof(int), 1, arquivo);
    registro->nomeClube = (char *)malloc((registro->tamNomeClube + 1) * sizeof(char));
    fread(registro->nomeClube, sizeof(char), registro->tamNomeClube, arquivo);
    registro->nomeClube[registro->tamNomeClube] = '\0';
}

void preeche_vazio(FILE *arquivo, int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        fwrite("$", sizeof(char), 1, arquivo);
    }
}

void ler_lixo(FILE *file){

    char lixo;
    do{
        fread(&lixo, sizeof(char), 1, file);
    } while (lixo == '$');
    fseek(file, -1, SEEK_CUR);
}
// Função responsável por atualizar a lista encadeada de registros removidos, de modo que ela
// esteja ordenada de forma crescente em relação ao tamanho de seus itens
void updateList(FILE * arquivo, long int novo, int tamanhoRegistroNovo) {
    long int atual = 0;             // Armazena o valor do byteOffset de um item da lista
    long int prox = 0;              // Armazenar o valor do byteOffset do sucessor de atual
    int tamanhoRegistroAtual = -1;  // Armazena o tamanho do registro de byteOffset atual

    // Ler o valor armazenado no topo (head)
    fseek(arquivo, 1, SEEK_SET);
    fread(&atual, sizeof(long int), 1, arquivo);

    // Caso o topo esteja vazio, o item novo é adicionado no topo
    if(atual == -1) {
        fseek(arquivo, 1, SEEK_SET);
        fwrite(&novo, sizeof(long int), 1, arquivo);
        return;
    }

    // Ler o valor do tamanho do registro atual
    fseek(arquivo, atual + 1, SEEK_SET);
    fread(&tamanhoRegistroAtual, sizeof(int), 1, arquivo);

    // Trata o caso no qual o registro já deve ser insirido em topo (cabeçalho).
    // Isso ocorre quando o tamanho do registro novo é menor que aquele em topo
    if (tamanhoRegistroNovo >= tamanhoRegistroAtual) {
        fread(&prox, sizeof(long int), 1, arquivo);

        // Atualizar o topo (cabeçalho), atribuindo o valor de novo
        fseek(arquivo, 1, SEEK_SET);
        fwrite(&novo, sizeof(long int), 1, arquivo);

        // Atualizar o proximo em novo de forma que ele "aponte" para atual
        fseek(arquivo, novo + 5, SEEK_SET);
        fwrite(&atual, sizeof(long int), 1, arquivo);

        return;
    }

    // Trata o restante dos casos, em que o registro novo será inserido no meio ou fim
    // da lista. Para isso, percorre-a até que seja encontrado o local para sua inserçao
    while (tamanhoRegistroNovo >= tamanhoRegistroAtual) {
        // Ler o valor do tamanho do registro atual
        fseek(arquivo, atual + 1, SEEK_SET);
        fread(&tamanhoRegistroAtual, sizeof(int), 1, arquivo);

        // Caso chegue ao fim da lista, sai do loop
        if (atual == -1)
            break;

        if (tamanhoRegistroNovo >= tamanhoRegistroAtual)
            fread(&atual, sizeof(long int), 1, arquivo);
    }
    fread(&prox, sizeof(long int), 1, arquivo);

    // Atualiza o valor proximo de novo de forma que ele aponte para prox
    fseek(arquivo, novo + 5, SEEK_SET);
    fwrite(&prox, sizeof(long int), 1, arquivo);
    
    // Atualiza o valor proximo de atual para que ele "aponte" para novo
    fseek(arquivo, atual + 5, SEEK_SET);
    fwrite(&novo, sizeof(long int), 1, arquivo);
}


// Função responsável por atualizar o cabeçalho do arquivo, modificando os valores contendo o
// número de registros presentes e removidos do arquivo
void updateCabecalho(FILE *arquivo, int nroRemocoes) {
    int nroReg;
    int nroRegRem;

    // Realiza a leitura do número de registros presentes e removidos no cabeçalho
    fseek(arquivo, 17, SEEK_SET);
    fread(&nroReg, sizeof(int), 1, arquivo);
    fread(&nroRegRem, sizeof(int), 1, arquivo);

    // Atualiza os valores de acordo com o número de remoções realizadas
    nroReg -= nroRemocoes;
    nroRegRem += nroRemocoes;

    // Reescreve os valores atualizados nos determinados campos 
    fseek(arquivo, 17, SEEK_SET);
    fwrite(&nroReg, sizeof(int), 1, arquivo);
    fwrite(&nroRegRem, sizeof(int), 1, arquivo);
}

// Função auxiliar para recuperar um registro do arquivo binário
void recuperarRegistro(REGISTRO **registro, FILE *arquivo, int byteOffset ,int *maxNomeJog, int *maxNacionalidade, int *maxNomeClube) {
    REGISTRO *reg = *registro; // Declaração e inicialização de um ponteiro para o registro
    int i = 0; // Variável de controle para loops

    if (byteOffset != -1)
        fseek(arquivo, byteOffset, SEEK_SET);

    // Lê os campos do registro do arquivo binário
    fread(&reg->removido, sizeof(char), 1, arquivo); // Lê o campo "removido" do registro
    fread(&reg->tamanhoRegistro, sizeof(int), 1, arquivo); // Lê o tamanho do registro
    fread(&reg->prox, sizeof(long int), 1, arquivo); // Lê o ponteiro para o próximo registro
    fread(&reg->id, sizeof(int), 1, arquivo); // Lê o ID do jogador
    fread(&reg->idade, sizeof(int), 1, arquivo); // Lê a idade do jogador


    // Lê o tamanho do nome do jogador e realoca memória se necessário
    fread(&reg->tamNomeJog, sizeof(int), 1, arquivo);
    if (reg->tamNomeJog > *maxNomeJog) { // Verifica se é necessário realocar memória para o nome do jogador
        *maxNomeJog = reg->tamNomeJog + 5; // Atualiza o tamanho máximo do nome do jogador
        reg->nomeJogador = realloc(reg->nomeJogador, *maxNomeJog * sizeof(char)); // Realoca memória para o nome do jogador
        if (reg->nomeJogador == NULL) exit(1); // Encerra o programa se não for possível alocar memória
    }

    // Lê o nome do jogador caractere por caractere
    for(i = 0; i < reg->tamNomeJog; i++)
                reg->nomeJogador[i] = getc(arquivo); // Lê um caractere do arquivo e o armazena no nome do jogador


    reg->nomeJogador[i] = '\0'; // Adiciona o caractere nulo ao final do nome do jogador
                

    // Lê o tamanho da nacionalidade do jogador e realoca memória se necessário
    fread(&reg->tamNacionalidade, sizeof(int), 1, arquivo);
    if (reg->tamNacionalidade > *maxNacionalidade) { // Verifica se é necessário realocar memória para a nacionalidade do jogador
        *maxNacionalidade = reg->tamNacionalidade + 5; // Atualiza o tamanho máximo da nacionalidade do jogador
        reg->nacionalidade = realloc(reg->nacionalidade, *maxNacionalidade * sizeof(char)); // Realoca memória para a nacionalidade do jogador
        if (reg->nacionalidade == NULL) exit(1); // Encerra o programa se não for possível alocar memória
    }
    // Lê a nacionalidade do jogador caractere por caractere
    for(i = 0; i < reg->tamNacionalidade; i++)
        reg->nacionalidade[i] = getc(arquivo); // Lê um caractere do arquivo e o armazena na nacionalidade do jogador
    reg->nacionalidade[i] = '\0'; // Adiciona o caractere nulo ao final da nacionalidade do jogador

    // Lê o tamanho do nome do clube do jogador e realoca memória se necessário
    fread(&reg->tamNomeClube, sizeof(int), 1, arquivo);
    if (reg->tamNomeClube > *maxNomeClube) { // Verifica se é necessário realocar memória para o nome do clube do jogador
        *maxNomeClube = reg->tamNomeClube + 5; // Atualiza o tamanho máximo do nome do clube do jogador
        reg->nomeClube = realloc(reg->nomeClube, *maxNomeClube * sizeof(char)); // Realoca memória para o nome do clube do jogador
        if (reg->nomeClube == NULL) exit(1); // Encerra o programa se não for possível alocar memória
    }
    // Lê o nome do clube do jogador caractere por caractere
    for(i = 0; i < reg->tamNomeClube; i++)
        reg->nomeClube[i] = getc(arquivo); // Lê um caractere do arquivo e o armazena no nome do clube do jogador
    reg->nomeClube[i] = '\0'; // Adiciona o caractere nulo ao final do nome do clube do jogador
}
// Função auxiliar para abrir e testar o arquivo
int testarArquivo(FILE *arquivo) {
    char status;
    fread(&status, sizeof(char), 1, arquivo);
    // Verifica se o arquivo ou a leitura do status falharam
    if (arquivo == NULL || status =='0') {
        printf("Falha no processamento do arquivo.\n");
        return 1; // Retorna 1 se a abertura ou a leitura do status falharam
    }

    return 0; // Retorna 0 se a abertura e a leitura do status foram bem-sucedidas
}
// Função para processar os comandos de busca
int comandoBusca(int *nroComandos, char (*comando)[5][20], char (*palavraChave)[5][100]) {
    int i;
    int j;
    char c = '\0';

    scanf("%d", nroComandos); // Lê o número de comandos de busca

    getchar(); // Descarta o caractere de quebra de linha

    for (j = 0; j < *nroComandos; j++) {
        c = getchar();
        for (i = 0; c != ' '; i++) { // Lê o comando de busca caractere por caractere até encontrar um espaço
            (*comando)[j][i] = c; // Armazena o caractere lido no comando
            c = getchar(); // Lê o próximo caractere
        }
        (*comando)[j][i] = '\0'; // Adiciona o caractere nulo ao final do comando

        scan_quote_string((*palavraChave)[j]); // Lê a palavra-chave da busca
        getchar(); // Descarta o caractere de quebra de linha após a palavra-chave
    }

    for (j = 0; j < *nroComandos; j++) {
        if ((strcmp((*comando)[j], "id") == 0))
            return j;
    }

    return -1;
}

// Função de busca nos registros
// Retorna:
//   0 se o registro possui todos os atributos buscados
//   1 se o registro não possui todos os atributos buscados
int busca(REGISTRO *registro, REGISTRO_IND *vetorInd, int nroComandos, char comando[5][20], char palavraChave[5][100]) {
    int temp; // Variável temporária para armazenar valores convertidos
    int retorno = 1; // Inicializa o retorno como 1 (registro não possui todos os atributos buscados)

    // Loop sobre todos os comandos de busca
    for (int i = 0; i < nroComandos; i++) {
        // Verifica se o comando atual é "idade"
        if (strcmp(comando[i], "idade") == 0) {
            temp = atoi(palavraChave[i]); // Converte a palavra-chave para inteiro
            // Se o valor convertido não corresponder à idade do registro, retorna o valor atual de retorno
            if (temp != registro->idade)
                return retorno;
        }
        // Verifica se o comando atual é "nomeJogador"
        if (strcmp(comando[i], "nomeJogador") == 0) {
            // Se o nome do jogador não corresponder à palavra-chave, retorna o valor atual de retorno
            if (strcmp(palavraChave[i], registro->nomeJogador) != 0)
                return retorno;
        }
        // Verifica se o comando atual é "nacionalidade"
        if (strcmp(comando[i], "nacionalidade") == 0) {
            // Se a nacionalidade não corresponder à palavra-chave, retorna o valor atual de retorno
            if (strcmp(palavraChave[i], registro->nacionalidade) != 0)
                return retorno;
        }
        // Verifica se o comando atual é "nomeClube"
        if (strcmp(comando[i], "nomeClube") == 0) {
            // Se o nome do clube não corresponder à palavra-chave, retorna o valor atual de retorno
            if (strcmp(palavraChave[i], registro->nomeClube) != 0)
                return retorno;
        }   
    }

    // Se todas as verificações passarem, o registro possui todos os atributos buscados
    // Retorna 0 se a busca deve continuar e 2 se a busca deve ser interrompida (apenas para "id")
    return (retorno - 1); // O registro possui os atributos buscados se o retorno for 0 ou 2
}
long int buscaId(REGISTRO *registro, REGISTRO_IND *vetorInd, int nroRegistros, int nroComandos, char comando[5][20], char palavraChave[5][100]) {
    int left = 0;
    int right = nroRegistros - 1;
    int middle = 0;

    int i = 0;
    int id = 0;

    while (i < nroComandos && strcmp(comando[i], "id") != 0)
        i++;

    id = atoi(palavraChave[i]);

    while(left <= right) {
        middle = left + (right - left) / 2;

        if (vetorInd[middle].id == id)
            return vetorInd[middle].byteOffset;
        if (vetorInd[middle].id < id)
            left = middle + 1;
        else   
            right = middle - 1;
    }

    // Caso o id não seja encontrado
    return -1;
}

// Função para imprimir os campos de um registro
void impressaoRegistro(REGISTRO *registro) {
    if (registro->removido == '0') { // Verifica se o registro não foi removido
        // Imprime o nome do jogador, ou "SEM DADO" se o campo estiver vazio
        if (registro->tamNomeJog != 0)
            printf("Nome do Jogador: %s\n", registro->nomeJogador);
        else
            printf("Nome do Jogador: SEM DADO\n");
        
        // Imprime a nacionalidade do jogador, ou "SEM DADO" se o campo estiver vazio
        if (registro->tamNacionalidade != 0)
            printf("Nacionalidade do Jogador: %s\n", registro->nacionalidade);
        else
            printf("Nacionalidade do Jogador: SEM DADO\n");
        
        // Imprime o clube do jogador, ou "SEM DADO" se o campo estiver vazio
        if (registro->tamNomeClube != 0)
            printf("Clube do Jogador: %s\n", registro->nomeClube);
        else
            printf("Clube do Jogador: SEM DADO\n");
        
        printf("\n"); // Imprime uma linha em branco para separar os registros
    }
}
// Função responsável por recuperar o arquivo de índice da memória secundária e passá-lo
// para a memória primária
REGISTRO_IND *recoverIndex(FILE *arquivo, FILE *indice) {
    int nroRegistros;
    REGISTRO_IND *registro;

    if ((getc(indice)) == '0') {
        printf("Falha no processamento do indice.\n");
        return NULL;
    }

    // Recuperar o número de registros 
    fseek(arquivo, 17, SEEK_SET);
    fread(&nroRegistros, sizeof(int), 1, arquivo);

    registro = malloc(sizeof(REGISTRO_IND) * (nroRegistros + 1));
        if (registro == NULL) {
        printf("Erro ao alocar memória.\n");
        return NULL;
    }

    // Passar o conteúdo do arquivo índice para a memória primaria
    for (int i = 0; i < nroRegistros; i++) {
        fread(&registro[i].id, sizeof(int), 1, indice);
        fread(&registro[i].byteOffset, sizeof(long int), 1, indice);
    }

    return(registro);
}

REGISTRO *criar_registro(int id, int idade, const char *nomeJogador, const char *nacionalidade, const char *clube) {
    REGISTRO *novoRegistro = (REGISTRO *)malloc(sizeof(REGISTRO));
    if (!novoRegistro) {
        printf("Falha no processamento do arquivo.\n");
        exit(1);
    }

    novoRegistro->id = id;
    novoRegistro->idade = idade;
    novoRegistro->tamNacionalidade = strlen(nacionalidade);
    novoRegistro->tamNomeJog = strlen(nomeJogador);
    novoRegistro->tamNomeClube = strlen(clube);

    novoRegistro->nomeJogador = (char *)malloc((novoRegistro->tamNomeJog + 1) * sizeof(char));
    novoRegistro->nacionalidade = (char *)malloc((novoRegistro->tamNacionalidade + 1) * sizeof(char));
    novoRegistro->nomeClube = (char *)malloc((novoRegistro->tamNomeClube + 1) * sizeof(char));

    if (!novoRegistro->nomeJogador || !novoRegistro->nacionalidade || !novoRegistro->nomeClube) {
        printf("Falha no processamento do arquivo.\n");
        exit(1);
    }

    strcpy(novoRegistro->nomeJogador, nomeJogador);
    strcpy(novoRegistro->nacionalidade, nacionalidade);
    strcpy(novoRegistro->nomeClube, clube);

    novoRegistro->tamanhoRegistro = 33 + novoRegistro->tamNomeJog + novoRegistro->tamNomeClube + novoRegistro->tamNacionalidade;
    novoRegistro->removido = '0';
    novoRegistro->prox = -1;

    return novoRegistro;
}
// Função responsável por inserir o registro no arquivo binário
void inserirRegistro(REGISTRO *registro, FILE *arquivo) {
    // Verifica se o registro ou o arquivo são nulos
    if (registro == NULL || arquivo == NULL)
        return; // Retorna se algum dos parâmetros for nulo

    // Escreve os campos do registro no arquivo binário
    putc(registro->removido, arquivo); // Escreve o campo removido no arquivo
    fwrite(&registro->tamanhoRegistro, sizeof(int), 1, arquivo); // Escreve o tamanho do registro no arquivo
    fwrite(&registro->prox, sizeof(long int), 1, arquivo); // Escreve o ponteiro para o próximo registro no arquivo
    fwrite(&registro->id, sizeof(int), 1, arquivo); // Escreve o ID do jogador no arquivo
    fwrite(&registro->idade, sizeof(int), 1, arquivo); // Escreve a idade do jogador no arquivo
    fwrite(&registro->tamNomeJog, sizeof(int), 1, arquivo); // Escreve o tamanho do nome do jogador no arquivo
    fputs(registro->nomeJogador, arquivo); // Escreve o nome do jogador no arquivo
    fwrite(&registro->tamNacionalidade, sizeof(int), 1, arquivo); // Escreve o tamanho da nacionalidade no arquivo
    fputs(registro->nacionalidade, arquivo); // Escreve a nacionalidade no arquivo
    fwrite(&registro->tamNomeClube, sizeof(int), 1, arquivo); // Escreve o tamanho do nome do clube no arquivo
    fputs(registro->nomeClube, arquivo); // Escreve o nome do clube no arquivo
}


// Função auxiliar responsável por alocar memória dinamicamente para o registro
void alocarRegistro(REGISTRO **registro, int maxNomeJog, int maxNacionalidade, int maxNomeClube) {
    // Aloca memória para a estrutura REGISTRO
    *registro = malloc(sizeof(REGISTRO));

    // Verifica se a alocação de memória foi bem-sucedida
    if (*registro == NULL) 
        return; // Retorna se não for possível alocar memória

    // Aloca memória para os campos de strings dentro da estrutura REGISTRO
    (*registro)->nomeJogador = malloc(maxNomeJog * sizeof(char));
    (*registro)->nomeClube = malloc(maxNacionalidade * sizeof(char));
    (*registro)->nacionalidade = malloc(maxNomeClube * sizeof(char));

    // Verifica se a alocação de memória foi bem-sucedida para os campos de strings
    if ((*registro)->nomeJogador == NULL || (*registro)->nomeClube == NULL || 
        (*registro)->nacionalidade == NULL)
        return; // Retorna se não for possível alocar memória
}