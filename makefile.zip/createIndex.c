#include "funcoes.h"
#include "funcoesAuxiliares.h"


void bubblesort(REGISTRO_IND* vetor[], int n) {
    int i, j;
    REGISTRO_IND* aux;
    for (i = 0; i < n; i++) {
        for (j = 0; j < n - 1; j++) {
            if (vetor[j]->id > vetor[j + 1]->id) {
                aux = vetor[j];
                vetor[j] = vetor[j + 1];
                vetor[j + 1] = aux;
            }
        }
    }
}

void createIndex(char *nomeArquivo, char *nomeIndice) {
    FILE *arquivoDados = fopen(nomeArquivo, "rb");
    if (arquivoDados == NULL) {
        printf("Falha no processamento do arquivo.\n");
        exit(1);
    }

    CABECALHO cabecalho;
    ler_cabecalho(arquivoDados, &cabecalho);
    if (cabecalho.status == '0') {
        printf("Falha no processamento do arquivo.\n");
        fclose(arquivoDados);
        exit(0);
    }

    FILE *arquivoIndice = fopen(nomeIndice, "wb");
    if (arquivoIndice == NULL) {
        printf("Falha no processamento do arquivo.\n");
        fclose(arquivoDados);
        exit(1);
    }
    
    CABECALHO_IND cabecalhoIndice;
    cabecalhoIndice.status = '0';
    fwrite(&cabecalhoIndice.status, sizeof(char), 1, arquivoIndice);

    int cont = cabecalho.nroRegArq + cabecalho.nroRegRem;

    REGISTRO_IND* vetor[cabecalho.nroRegArq];
    int aux = 0;

    for (int i = 0; i < cont; i++) {
        long int byteOffset = ftell(arquivoDados);
        REGISTRO* registro = malloc(sizeof(REGISTRO));
        ler_registro(registro, arquivoDados);
        ler_lixo(arquivoDados);
        if (registro->removido == '0') {
            REGISTRO_IND* registroIndice = malloc(sizeof(REGISTRO_IND));
            registroIndice->id = registro->id;
            registroIndice->byteOffset = byteOffset;
            vetor[aux] = registroIndice;
            aux++;
        }
        free(registro);
    }

    bubblesort(vetor, aux);

    for (int i = 0; i < aux; i++) {
        fwrite(&vetor[i]->id, sizeof(int), 1, arquivoIndice);
        fwrite(&vetor[i]->byteOffset, sizeof(long int), 1, arquivoIndice);
        free(vetor[i]);
    }

    fseek(arquivoIndice, 0, SEEK_SET);
    cabecalhoIndice.status = '1';
    fwrite(&cabecalhoIndice.status, sizeof(char), 1, arquivoIndice);
   

    fclose(arquivoDados);
    fclose(arquivoIndice);
}

